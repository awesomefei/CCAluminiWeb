var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Controllers;
    (function (Controllers) {
        var LoginController = (function () {
            function LoginController(loginService, $state) {
                this.loginService = loginService;
                this.$state = $state;
            }
            LoginController.prototype.saveUser = function () {
                var _this = this;
                this.loginService.saveUser(this.user)
                    .then(function () {
                    _this.$state.go('home');
                })
                    .catch(function () {
                    console.log('something went wrong');
                });
            };
            return LoginController;
        }());
        Controllers.LoginController = LoginController;
    })(Controllers = ccalummiwebsite.Controllers || (ccalummiwebsite.Controllers = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
