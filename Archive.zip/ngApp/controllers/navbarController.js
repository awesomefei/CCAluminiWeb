var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Contollers;
    (function (Contollers) {
        var NavbarController = (function () {
            function NavbarController(loginService, $state) {
                this.loginService = loginService;
                this.$state = $state;
                this.getFirstname();
            }
            NavbarController.prototype.getUsername = function () {
                return this.loginService.getUsername();
            };
            NavbarController.prototype.login = function () {
                var _this = this;
                this.loginService.login(this.loginInfo)
                    .then(function () {
                    _this.$state.go('home');
                    document.getElementById('loginForm').reset();
                })
                    .catch(function () {
                    alert('Login failed');
                });
            };
            NavbarController.prototype.logout = function () {
                this.loginService.logout();
                this.$state.go('login');
            };
            NavbarController.prototype.gotoAccount = function () {
                this.$state.go('account');
            };
            NavbarController.prototype.getFirstname = function () {
                this.firstname = this.loginService.getFirstname();
            };
            return NavbarController;
        }());
        angular.module('ccalummiwebsite').controller('navbarController', NavbarController);
    })(Contollers = ccalummiwebsite.Contollers || (ccalummiwebsite.Contollers = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
