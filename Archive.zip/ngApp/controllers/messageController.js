var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Controllers;
    (function (Controllers) {
        var MessageController = (function () {
            function MessageController(messageService, $state) {
                this.messageService = messageService;
                this.$state = $state;
                this.getMessages();
            }
            MessageController.prototype.getMessages = function () {
                this.messages = this.messageService.getMessages();
            };
            MessageController.prototype.getMessageDetails = function (id) {
                console.log(id);
                this.$state.go('message', { id: id });
            };
            return MessageController;
        }());
        Controllers.MessageController = MessageController;
        var MessageDetailsController = (function () {
            function MessageDetailsController(messageService, $stateParams) {
                this.messageService = messageService;
                this.$stateParams = $stateParams;
                var messId = this.$stateParams['id'];
                this.getMessage(messId);
            }
            MessageDetailsController.prototype.getMessage = function (messId) {
                this.message = this.messageService.getMessage(messId);
                console.log(messId);
            };
            return MessageDetailsController;
        }());
        Controllers.MessageDetailsController = MessageDetailsController;
    })(Controllers = ccalummiwebsite.Controllers || (ccalummiwebsite.Controllers = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
