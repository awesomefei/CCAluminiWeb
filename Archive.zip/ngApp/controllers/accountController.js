var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Controllers;
    (function (Controllers) {
        var AccountController = (function () {
            function AccountController(filepickerService, $scope, $state) {
                this.filepickerService = filepickerService;
                this.$scope = $scope;
                this.$state = $state;
                this.message = 'hello from AccountController';
                this.$state.go('account.timeline');
            }
            AccountController.prototype.pickFile = function () {
                this.filepickerService.pick({ mimetype: 'image/*' }, this.fileUploaded.bind(this));
            };
            AccountController.prototype.fileUploaded = function (file) {
                console.log('!!!!!!!!!!!!pickFile()');
                this.file = file;
                this.$scope.$apply();
            };
            return AccountController;
        }());
        Controllers.AccountController = AccountController;
        var AccountAboutController = (function () {
            function AccountAboutController() {
                this.message = 'Hello from the account about page!';
            }
            return AccountAboutController;
        }());
        Controllers.AccountAboutController = AccountAboutController;
        var AccountAboutDetailEditController = (function () {
            function AccountAboutDetailEditController() {
                this.message = 'Hello from the detailEdit controller';
            }
            return AccountAboutDetailEditController;
        }());
        Controllers.AccountAboutDetailEditController = AccountAboutDetailEditController;
        var AccountPhotoController = (function () {
            function AccountPhotoController() {
                this.message = 'hello from the AccountPhotoController controler';
            }
            return AccountPhotoController;
        }());
        Controllers.AccountPhotoController = AccountPhotoController;
        var AccountCheckinController = (function () {
            function AccountCheckinController() {
                this.message = 'hello from the AccountCheckinController controler';
            }
            return AccountCheckinController;
        }());
        Controllers.AccountCheckinController = AccountCheckinController;
    })(Controllers = ccalummiwebsite.Controllers || (ccalummiwebsite.Controllers = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
