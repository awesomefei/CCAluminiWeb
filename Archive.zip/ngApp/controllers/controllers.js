var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Controllers;
    (function (Controllers) {
        var HomeController = (function () {
            function HomeController() {
                this.message = 'Hello from the home page!';
            }
            return HomeController;
        }());
        Controllers.HomeController = HomeController;
    })(Controllers = ccalummiwebsite.Controllers || (ccalummiwebsite.Controllers = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
