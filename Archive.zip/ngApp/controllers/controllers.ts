namespace ccalummiwebsite.Controllers {

    export class HomeController {
        public message = 'Hello from the home page!';
    }


    

}
