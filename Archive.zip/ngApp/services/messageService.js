var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Services;
    (function (Services) {
        var MessageService = (function () {
            function MessageService($resource) {
                this.$resource = $resource;
                this.messageResource = $resource('api/messages/:id');
            }
            MessageService.prototype.getMessages = function () {
                return this.messageResource.query();
            };
            MessageService.prototype.getMessage = function (id) {
                return this.messageResource.get({ id: id });
            };
            return MessageService;
        }());
        Services.MessageService = MessageService;
        angular.module('ccalummiwebsite').service('messageService', MessageService);
    })(Services = ccalummiwebsite.Services || (ccalummiwebsite.Services = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
