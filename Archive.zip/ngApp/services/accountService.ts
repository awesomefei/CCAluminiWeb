namespace ccalummiwebsite.Services{
    export class AccountService{
        private accountResource;
        // constructor(
        //     private $resource:ng.resource.IResourceService,
        //
        // ){
        //     this.accountResource= this.$resource('/api/users/:id')
        // }
        getAccountOnService(id){

        }
    }
    angular.module('ccalummiwebsite').service('accountService', AccountService);
}
