var ccalummiwebsite;
(function (ccalummiwebsite) {
    var Services;
    (function (Services) {
        var AccountService = (function () {
            function AccountService() {
            }
            AccountService.prototype.getAccountOnService = function (id) {
            };
            return AccountService;
        }());
        Services.AccountService = AccountService;
        angular.module('ccalummiwebsite').service('accountService', AccountService);
    })(Services = ccalummiwebsite.Services || (ccalummiwebsite.Services = {}));
})(ccalummiwebsite || (ccalummiwebsite = {}));
