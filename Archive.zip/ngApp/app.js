var ccalummiwebsite;
(function (ccalummiwebsite) {
    angular.module('ccalummiwebsite', ['ui.router', 'ngResource', 'ui.bootstrap', 'yaru22.angular-timeago', 'angular-filepicker']).config(function (filepickerProvider, $stateProvider, $urlRouterProvider, $locationProvider) {
        filepickerProvider.setKey('AKajIDUelSihS59ufHbW1z');
        $stateProvider
            .state('account', {
            url: '/account',
            templateUrl: '/ngApp/views/account/account.html',
            controller: ccalummiwebsite.Controllers.AccountController,
            controllerAs: 'vm'
        })
            .state('account.timeline', {
            templateUrl: '/ngApp/views/account/account.timeline.html',
            controller: ccalummiwebsite.Controllers.AccountController,
            controllerAs: 'vm',
        })
            .state('account.about', {
            templateUrl: '/ngApp/views/account/account.about.html',
            controller: ccalummiwebsite.Controllers.AccountAboutController,
            controllerAs: 'vm',
        })
            .state('account.photo', {
            templateUrl: '/ngApp/views/account/account.photo.html',
            controller: ccalummiwebsite.Controllers.AccountPhotoController,
            controllerAs: 'vm',
        })
            .state('account.checkin', {
            templateUrl: '/ngApp/views/account/account.checkin.html',
            controller: ccalummiwebsite.Controllers.AccountCheckinController,
            controllerAs: 'vm',
        })
            .state('account.about.detailEdit', {
            templateUrl: '/ngApp/views/about/about.detailEdit.html',
            controller: ccalummiwebsite.Controllers.AccountAboutDetailEditController,
            controllerAs: 'vm',
        })
            .state('home', {
            url: '/',
            templateUrl: '/ngApp/views/home.html',
            controller: ccalummiwebsite.Controllers.HomeController,
            controllerAs: 'controller'
        })
            .state('login', {
            url: '/login',
            templateUrl: '/ngApp/views/login.html',
            controller: ccalummiwebsite.Controllers.LoginController,
            controllerAs: 'vm'
        })
            .state('inbox', {
            url: '/inbox',
            templateUrl: '/ngApp/views/inbox.html',
            controller: ccalummiwebsite.Controllers.MessageController,
            controllerAs: 'vm'
        })
            .state('message', {
            url: '/message/:id',
            templateUrl: '/ngApp/views/messageDetails.html',
            controller: ccalummiwebsite.Controllers.MessageDetailsController,
            controllerAs: 'vm'
        })
            .state('notFound', {
            url: '/notFound',
            templateUrl: '/ngApp/views/notFound.html'
        });
        $urlRouterProvider.otherwise('/notFound');
        $locationProvider.html5Mode(true);
    });
})(ccalummiwebsite || (ccalummiwebsite = {}));
