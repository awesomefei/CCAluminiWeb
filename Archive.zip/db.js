"use strict";
var mongoose = require('mongoose');
var user_1 = require('./model/user');
var URL = 'mongodb://admin:Secret123!@ds019876.mlab.com:19876/codercampsalumini';
var Database = (function () {
    function Database() {
    }
    Database.connect = function () {
        mongoose.connect(URL);
        var db = mongoose.connection;
        db.on('err', function () {
            console.log('connection err');
        });
        db.once('open', function () {
            console.log('connected to database!!!');
        });
        user_1.default
            .findOne({ username: 'codercamps@gmail.com' })
            .then(function (user) {
            if (!user) {
                var adminUser = new user_1.default();
                adminUser.username = 'codercamps@gmail.com';
                adminUser.setPassword('Secret123!');
                adminUser.admin = true;
                adminUser.firstname = "Dan";
                adminUser
                    .save()
                    .then(function () {
                    console.log('Admin successfully created');
                })
                    .catch(function () {
                    console.log('Admin creation went wrong');
                });
            }
            else {
                console.log('Admin already exists in Database');
            }
        })
            .catch(function (err) {
            console.log(err);
        });
    };
    return Database;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Database;
