"use strict";
var express = require('express');
var mongodb = require("mongodb");
var jwt = require('jsonwebtoken');
var message_1 = require('../model/message');
var messageRouter = express.Router();
var ObjectId = mongodb.ObjectID;
messageRouter.get('/', function (req, res) {
    message_1.default.find().populate('userRecieve').then(function (messages) {
        res.send(messages);
    }).catch(function () {
        res.sendStatus(500);
    });
});
messageRouter.get('/:id', function (req, res) {
    message_1.default.findById(req.params['id'])
        .then(function (message) {
        res.send(message);
    }).catch(function (err) {
        res.send(err);
    });
});
messageRouter.post('/:recieverId', authorize, function (req, res) {
    var message = new message_1.default();
    message.userSend = req.user.id;
    message.userRecieve = req.params['recieverId'];
    message.title = req.body.title;
    message.message = req.body.message;
    message.timeCreate = new Date();
    message.save()
        .then(function (message) {
        res.send(message);
    }).catch(function (err) {
        res.status(400).send(err);
    });
});
function authorize(req, res, next) {
    var token = req['token'];
    jwt.verify(token, 'SuperSecret', function (err, decoded) {
        if (err) {
            res.sendStatus(401);
        }
        else {
            req.user = decoded;
            console.log(decoded);
            next();
        }
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = messageRouter;
