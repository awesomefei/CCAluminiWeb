"use strict";
var express = require('express');
var passport = require('passport');
var passportLocal = require('passport-local');
var jwt = require('jsonwebtoken');
var user_1 = require('../model/user');
var userRouter = express.Router();
userRouter.get('/', function (req, res) {
    user_1.default.find().then(function (users) {
        res.send(users);
    }).catch(function () {
        res.status(500);
    });
});
userRouter.delete('/:id', function (req, res) {
    user_1.default.findByIdAndRemove(req.params['id']).then(function (user) {
        res.sendStatus(200);
    }).catch(function () {
        res.sendStatus(400);
    });
});
var LocalStrategy = passportLocal.Strategy;
passport.serializeUser(function (user, done) {
    done(null, user.id);
});
passport.deserializeUser(function (id, done) {
    user_1.default.findById(id, function (err, user) {
        done(err, user);
    });
});
passport.use(new LocalStrategy(function (username, password, done) {
    user_1.default.findOne({ username: username.trim() })
        .then(function (user) {
        if (!user) {
            console.log('no user found');
            return done(null, false, { message: 'incorrect email' });
        }
        if (!user.validatePassword(password)) {
            console.log('incorrect pw');
            return done(null, false, { message: 'incorrect password' });
        }
        user.password = null;
        return done(null, user);
    })
        .catch(function (err) {
        return done(err);
    });
}));
userRouter.post('/register', register, passport.authenticate('local', { failureRedirect: '/login' }), login);
function register(req, res, next) {
    req.checkBody('firstname', 'Firstname is required').notEmpty();
    req.checkBody('lastname', 'Lastname is required').notEmpty();
    req.checkBody('username', 'Email is not valid').isEmail();
    req.checkBody('password', 'Password is requried').notEmpty();
    req.checkBody('confirmPassword', 'Password do not match').equals(req.body.password);
    var errors = req.validationErrors();
    if (errors) {
        res.status(400).send(errors);
    }
    else {
        var newUser = new user_1.default();
        console.log(req);
        newUser.firstname = req.body.firstname;
        newUser.lastname = req.body.lastname;
        newUser.birthdateMonth = req.body.birthdateMonth;
        newUser.birthdateDay = req.body.birthdateDay;
        newUser.birthdateYear = req.body.birthdateYear;
        newUser.username = req.body.username;
        newUser.setPassword(req.body.password);
        console.log(newUser.password);
        newUser.save()
            .then(function (user) {
            console.log('User has been saved');
            next();
        })
            .catch(function (err) {
            console.log(err);
        });
    }
    function login(req, res) {
        if (req.isAuthenticated()) {
            var data = {
                token: req.user.generateToken(),
                admin: req.user.admin,
                username: req.user.username,
                firstname: req.user.firstname
            };
            res.send(data);
        }
    }
}
userRouter.post('/login', passport.authenticate('local', { failureRedirect: '/login' }), login);
function login(req, res) {
    if (req.isAuthenticated()) {
        var data = {
            token: req.user.generateToken(),
            admin: req.user.admin,
            username: req.user.username,
            firstname: req.user.firstname
        };
        console.log(data);
        res.send(data);
    }
    else {
        res.send('you are not authenticated');
    }
}
function authorize(req, res, next) {
    var token = req['token'];
    jwt.verify(token, 'SuperSecret', function (err, decoded) {
        if (err) {
            res.sendStatus(401);
        }
        else {
            req.user = decoded;
            console.log(decoded);
            next();
        }
    });
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = userRouter;
