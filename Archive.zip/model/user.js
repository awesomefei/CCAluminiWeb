"use strict";
var mongoose = require('mongoose');
var jwt = require('jsonwebtoken');
var crypto = require('crypto-js');
var userSchema = new mongoose.Schema({
    pics: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: "Pic"
        }],
    friendsList: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        }],
    activities: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Activity'
        }],
    hobby: {
        type: String,
        required: false,
    },
    currentCity: {
        type: String,
        required: false,
    },
    onlineStatus: {
        type: String,
        enum: ['online', 'offline'],
    },
    detailsAboutUser: {
        type: String,
        required: false,
    },
    employment: {
        type: String,
        required: false
    },
    education: {
        type: String,
        required: false
    },
    profileImageUrl: {
        type: String,
        required: false,
    },
    workingExperience: {
        type: String,
        required: false,
    },
    firstname: {
        type: String,
        required: false,
        trim: true,
    },
    lastname: {
        type: String,
        required: false,
        trim: true,
    },
    birthdateMonth: {
        type: String,
        required: false,
    },
    birthdateDay: {
        type: String,
        required: false,
    },
    birthdateYear: {
        type: String,
        required: false,
    },
    username: {
        type: String,
        required: true,
        match: /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
    },
    password: {
        type: String,
        required: true,
    },
    admin: {
        type: Boolean,
        default: false,
        required: false,
    }
});
userSchema.method('setPassword', function (password) {
    this.password = crypto.AES.encrypt(password, 'SuperSecret');
});
userSchema.method('validatePassword', function (password) {
    var hash = crypto.AES.decrypt(this.password, 'SuperSecret');
    return password === hash.toString(crypto.enc.Utf8);
});
userSchema.method('generateToken', function () {
    return jwt.sign({
        id: this._id,
        username: this.username,
        admin: this.admin,
    }, 'SuperSecret');
});
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = mongoose.model('User', userSchema);
