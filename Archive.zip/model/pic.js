"use strict";
var mongoose = require('mongoose');
var picSchema = new mongoose.Schema({
    picName: {
        type: String,
        required: false
    },
    date: {
        type: Date,
        required: false,
        default: new Date()
    },
    location: {
        type: String,
        required: false
    },
    describtion: {
        type: String,
        required: false
    },
    tag: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Tag',
        }],
});
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = mongoose.model('Pic', picSchema);
